import time
from locust import HttpUser, task, between
import json


class QuickstartUser(HttpUser):
    wait_time = between(1, 5)

    @task
    def view_items(self):
        body = {"anonymousId": "23adfd82-aa0f-45a7-a756-24f2a7a4c895", "context": {"library": {"name": "analytics.js", "version": "2.11.1"}, "page": {"path": "/academy/", "referrer": "", "search": "", "title": "Analytics Academy", "url": "https://segment.com/academy/"}, "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.36", "ip": "108.0.78.21"}, "event": "Product List Filtered", "messageId": "ajs-f8ca1e4de5024d9430b3928bd8ac6b96", "properties": {"title": "Intro to Analytics", "list_id": "abd2354", "orderId": "abc55", "total": 999.9, "shipping": 23.99, "tax": 25.99, "currency": "CAD", "coupon": "coupon", "affiliation": "affiliation", "products": [
            {"quantity": 1, "price": 24.75, "name": "deepin product", "category": "cat 1", "sku": "p-298"}, {"quantity": 3, "price": 24.75, "name": "other product", "category": "cat 2", "sku": "p-299", "currency": "EUR"}], "filters": [{"type": "department", "value": "beauty"}, {"type": "price", "value": "under"}], "sorts": [{"type": "price", "value": "desc"}]}, "receivedAt": "2015-12-12T19:11:01.266Z", "sentAt": "2015-12-12T19:11:01.169Z", "timestamp": "2015-12-12T19:11:01.249Z", "type": "track", "userId": "hamed_", "originalTimestamp": "2015-12-12T19:11:01.152Z"}
        url = '/v1/track'
        headers = {'content-type': 'application/json',
                   'write-key': 'dHuUTYnzLb4bTV2JwQDH'}
        self.client.post(url, json=body, headers=headers)
