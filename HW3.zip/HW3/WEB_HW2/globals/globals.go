package globals

var Secret = []byte("secret")

const Userkey = "user"